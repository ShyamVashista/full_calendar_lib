import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  calendarOption: any = {};
  title = 'calendar-usage-app';
  calenderData: any = [];
  colorDict: any = {};

  constructor() {

  }

  ngOnInit() {
    let data:any = [];
    this.bindCalendar(data, true);
  }
  private initializeCalender(data: any, refresh: boolean = false) {
    data = data || [];
   
    this.calendarOption = {
      editable: true,            //eventLimit: false,
      contentHeight: 'auto',
      events: data,
      headerToolbar: {
        left: 'prev,next',
        center: 'title',
        right: 'dayGridMonth,timeGridWeek'
      },
      eventClick: this.handleEventClick.bind(this)    
    };    
  }
  handleEventClick(clickInfo:any) {
    this.eventClick(clickInfo);
  }  
  private bindCalendar(tmpdata: any, refresh: boolean) {
    this.calenderData = [];
    for (var i = 0; i < tmpdata.length; i++) {
      this.calenderData.push({
        id: tmpdata[i].Id,
        description: tmpdata[i].Description,
        itemMainKey: tmpdata[i].ItemMainKey,
        type: tmpdata[i].ItemType,
        title: tmpdata[i].title,
        Id: tmpdata[i].Id,
        projectId: tmpdata[i].ProjectId,
        projectNumber: tmpdata[i].ProjectNumber,
        projectTitle: tmpdata[i].ProjectTitle,
        currency: tmpdata[i].Currency,
        projectArchive: tmpdata[i].ProjectArchive,

        recordNumber: tmpdata[i].RecordNumber,
        startDate: tmpdata[i].Date ? tmpdata[i].Date.split('T')[0] : '',
        start: tmpdata[i].Date ? tmpdata[i].Date.split('T')[0] : '',
        end: tmpdata[i].EndDate ? tmpdata[i].EndDate.split('T')[0] : '',
        formattedDate: tmpdata[i].Date,
        numericDate: tmpdata[i].Date,
       

        allDay: true,
        backgroundColor: this.colorDict[tmpdata[i].FeatureId],
        textColor: null,
        saveTimezone: 'UTC',
        FeatureGrouping: tmpdata[i].FeatureGrouping,
        Feature: tmpdata[i].Feature
      });
    }
    debugger;
    //this.calendarOption = null;
    this.initializeCalender(this.calenderData, refresh);
  }

  eventClick(e: any) {   

    
  }
  get yearMonth(): string {
    const dateObj = new Date();
    return dateObj.getUTCFullYear() + '-' + (dateObj.getUTCMonth() + 1);
  }  

}
