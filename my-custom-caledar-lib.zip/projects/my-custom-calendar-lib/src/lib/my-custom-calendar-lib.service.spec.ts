import { TestBed } from '@angular/core/testing';

import { MyCustomCalendarLibService } from './my-custom-calendar-lib.service';

describe('MyCustomCalendarLibService', () => {
  let service: MyCustomCalendarLibService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MyCustomCalendarLibService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
