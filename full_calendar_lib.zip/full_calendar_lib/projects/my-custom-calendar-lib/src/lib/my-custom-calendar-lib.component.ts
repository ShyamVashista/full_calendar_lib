
import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { CalendarOptions, FullCalendarComponent } from '@fullcalendar/angular';
import dayGridPlugin from '@fullcalendar/daygrid';
import interactionPlugin from '@fullcalendar/interaction';
import timeGridPlugin from '@fullcalendar/timegrid';

@Component({
  selector: 'lib-my-custom-calendar-lib',
  template: `
    <p>
      my-custom-calendar-lib works!
    </p>
<full-calendar #fullcalendar
                           id="divFullcalendar"
                           [options]="_calendarOption"></full-calendar>
  `,
  styles: [
  ]
})
export class MyCustomCalendarLibComponent implements OnInit {

  dateForcalendar: any;
  _calendarOption: CalendarOptions = {};

  @Input()
  set calendarOption(val: CalendarOptions) {
    this._calendarOption = val;
    this._calendarOption.plugins = [dayGridPlugin, timeGridPlugin, interactionPlugin];
  }

  @ViewChild(FullCalendarComponent) fullCalendar: FullCalendarComponent | undefined;
  constructor() {
    this.dateForcalendar = new Date();
  }

  ngOnInit(): void {
  }

  eventrender(event: any) {
    event.element[0].querySelectorAll(".fc-content")[0].setAttribute("data-tooltip", event.event.title);
  }

  handleEventClick(clickInfo: any) {
    this.eventClick(clickInfo);
  }

  eventClick(e: any) { }

}
