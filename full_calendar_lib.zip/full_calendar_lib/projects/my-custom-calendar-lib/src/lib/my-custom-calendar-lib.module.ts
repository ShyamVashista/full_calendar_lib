import { NgModule } from '@angular/core';
import { FullCalendarModule } from '@fullcalendar/angular';
import { MyCustomCalendarLibComponent } from './my-custom-calendar-lib.component';



@NgModule({
  declarations: [
    MyCustomCalendarLibComponent
  ],
  imports: [FullCalendarModule
  ],
  exports: [
    MyCustomCalendarLibComponent
  ]
})
export class MyCustomCalendarLibModule { }
