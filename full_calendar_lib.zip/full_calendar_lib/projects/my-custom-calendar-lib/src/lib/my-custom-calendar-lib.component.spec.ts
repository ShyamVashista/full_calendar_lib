import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MyCustomCalendarLibComponent } from './my-custom-calendar-lib.component';

describe('MyCustomCalendarLibComponent', () => {
  let component: MyCustomCalendarLibComponent;
  let fixture: ComponentFixture<MyCustomCalendarLibComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MyCustomCalendarLibComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MyCustomCalendarLibComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
